package edu.bu.mbta.alertByStop;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.PutItemRequest;
import com.amazonaws.services.dynamodbv2.model.PutItemResult;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.dynamodbv2.model.TableDescription;
import com.amazonaws.services.dynamodbv2.util.Tables;

import edu.bu.mbta.api.AlertHeadersByStop;
import edu.bu.mbta.entity.AlertEntity;
import edu.bu.mbta.entity.AlertHeadersByStopEntity;

public class AlertByStop {
	public static void AllAlerts(AmazonDynamoDBClient dynamoDB) throws Exception {
		String tableName1 = "AlertsByStop";
		
		if (Tables.doesTableExist(dynamoDB, tableName1)) {
		    System.out.println("Table " + tableName1 + " is already ACTIVE");
		} else {
		    CreateTableRequest createTableRequest = new CreateTableRequest().withTableName(tableName1)
		        .withKeySchema(new KeySchemaElement().withAttributeName("stop_id").withKeyType(KeyType.HASH))
		        .withAttributeDefinitions(new AttributeDefinition().withAttributeName("stop_id").withAttributeType(ScalarAttributeType.S))
		        .withProvisionedThroughput(new ProvisionedThroughput().withReadCapacityUnits(1L).withWriteCapacityUnits(1L));
		        TableDescription createdTableDescription = dynamoDB.createTable(createTableRequest).getTableDescription();
		    System.out.println("Created Table: " + createdTableDescription);
		
		        // Wait for it to become active
		    System.out.println("Waiting for " + tableName1 + " to become ACTIVE...");
		    Tables.awaitTableToBecomeActive(dynamoDB, tableName1);
		}
		
		
        ArrayList<String> AllIds = fetchItems("All-Stops-Table", dynamoDB);
        

        while(AllIds.size() > 0) {
        	int index = AllIds.size() - 1;
        	String id = AllIds.remove(index);
            
        	DynamoDB dynamoDB1 = new DynamoDB(dynamoDB);
     	   	Table table = dynamoDB1.getTable("AlertHeaderByStop");
     	   	
     	   	HashMap<String, String> nameMap = new HashMap<String, String>();
     	   	nameMap.put("#nm", "stop_id"); 
            
     	   	HashMap<String, Object> valueMap = new HashMap<String, Object>();
     	   	valueMap.put(":yyyy", id);
            
       		QuerySpec spec = new QuerySpec()
       			.withKeyConditionExpression("#nm = :yyyy")
       			.withNameMap(nameMap)
       			.withValueMap(valueMap);
       	
       		ItemCollection<QueryOutcome> items = table.query(spec);

	        System.out.println("\nfindRepliesForAThread results:");
	        Iterator<Item> iterator = items.iterator();
	        StringBuilder str = new StringBuilder();
	        while (iterator.hasNext()) {
	        	str.append(iterator.next());
	        }
	        String string = str.toString();
	      	System.out.println("alertheader: "+string);
	 
	   		int index1 = string.lastIndexOf("=");
    		int index2 = string.lastIndexOf("}");
	       	if(index1 == -1 && index2 == -1) continue;
	       	string = string.substring(index1, index2);
	       	System.out.println(string);
	       	index2 = string.lastIndexOf("}");
	       	System.out.println("index2: "+ index2);
	       	string = string.substring(1, index2);
	       
	       	System.out.println("alertid: "+string);
	       	System.out.println("comma index:"+ string.indexOf(","));
	       		
	        if(string.indexOf(",") != -1) {
	       		String[] array = string.split(",");
	       		StringBuilder result = new StringBuilder();
	       		StringBuilder alertids = new StringBuilder();
	       		for(int i = 0; i < array.length; i++) {
	       			DynamoDB dynamoDB2 = new DynamoDB(dynamoDB);
	       	 	   	Table table2 = dynamoDB2.getTable("All-Alerts-Table");
	       	 	   	
	       	 	   	HashMap<String, String> nameMap2 = new HashMap<String, String>();
	       	 	   	nameMap2.put("#nm", "alert_id"); 
	       	        
	       	 	   	HashMap<String, Object> valueMap2 = new HashMap<String, Object>();
	       	 	   	valueMap2.put(":yyyy", array[i]);
	       	        
	       	   		QuerySpec spec2 = new QuerySpec()
	       	   			.withKeyConditionExpression("#nm = :yyyy")
	       	   			.withNameMap(nameMap2)
	       	   			.withValueMap(valueMap2);
	       	   	
	       	   		ItemCollection<QueryOutcome> items2 = table2.query(spec2);

		            System.out.println("\nfindRepliesForAThread results:");
		            Iterator<Item> iterator2 = items2.iterator();
		            StringBuilder str2 = new StringBuilder();
		            while (iterator2.hasNext()) {
		            	str2.append(iterator2.next());
		            }
		            String string2 = str.toString();
		            System.out.println("alert detail: " + string2);
		            alertids.append(array[i]);
		            result.append(string2);
	       		  }       			
	       			if( result.toString() == "" ||result == null||string==null) continue;
		            Map<String, AttributeValue> item2 = newItem(id, alertids.toString(), result.toString());
		            PutItemRequest putItemRequest2 = new PutItemRequest(tableName1, item2);
		            PutItemResult putItemResult2 = dynamoDB.putItem(putItemRequest2);
		            System.out.println("Result: " + putItemResult2.toString());
	       		} else {
	       			System.out.println("Here!");
	       			DynamoDB dynamoDB2 = new DynamoDB(dynamoDB);
	       	 	   	Table table2 = dynamoDB2.getTable("All-Alerts-Table");
	       	 	   	
	       	 	   	HashMap<String, String> nameMap2 = new HashMap<String, String>();
	       	 	   	nameMap2.put("#nm", "alert_id"); 
	       	        
	       	 	   	HashMap<String, Object> valueMap2 = new HashMap<String, Object>();
	       	 	   	valueMap2.put(":yyyy", string);
	       	        
	       	   		QuerySpec spec2 = new QuerySpec()
	       	   			.withKeyConditionExpression("#nm = :yyyy")
	       	   			.withNameMap(nameMap2)
	       	   			.withValueMap(valueMap2);
	       	   	
	       	   		ItemCollection<QueryOutcome> items2 = table2.query(spec2);
	       	   		if(items2.equals(null)) continue;

		            System.out.println("\nfindRepliesForAThread results:");
		            Iterator<Item> iterator2 = items2.iterator();
		            StringBuilder str2 = new StringBuilder();
		            while (iterator2.hasNext()) {
		              	str2.append(iterator2.next());
		            }
		            String string2 = str2.toString();
		            
		            System.out.println("alert detail: " + string2);
//		            if(string!=null && string2 != null && string2 != "") {
		            if(string2.equals("N/A") || string2.equals("")) continue;
			            Map<String, AttributeValue> item2 = newItem(id, string, string2);
			            PutItemRequest putItemRequest2 = new PutItemRequest(tableName1, item2);
			            PutItemResult putItemResult2 = dynamoDB.putItem(putItemRequest2);
			            System.out.println("Result: " + putItemResult2.toString());
//		            }
	       		}
//       		}
     		
        }
	}
	
	private static ArrayList<String> fetchItems(String tableName, AmazonDynamoDBClient dynamoDB) {
	     
	    ArrayList<String> ids = new ArrayList<String>();
	 
	    ScanResult result = null;
	 
	    do{
	        ScanRequest req = new ScanRequest();
	        req.setTableName(tableName);
	 
	        if(result != null){
	            req.setExclusiveStartKey(result.getLastEvaluatedKey());
	        }
	         
	        result = dynamoDB.scan(req);
	 
	        List<Map<String, AttributeValue>> rows = result.getItems();
	 
	        for(Map<String, AttributeValue> map : rows){
	            try{
	                AttributeValue v = map.get("stop_id");
	                String id = v.getS();
	                ids.add(id);
	            } catch (NumberFormatException e){
	                System.out.println(e.getMessage());
	            }
	        }
	    } while(result.getLastEvaluatedKey() != null);
	     
	    System.out.println("Result size: " + ids.size());
	 
	    return ids;
	}
	
	
	private static Map<String, AttributeValue> newItem(String stop_id, String alertid, String information) {
        Map<String, AttributeValue> item = new HashMap<String, AttributeValue>();
        item.put("stop_id", new AttributeValue(stop_id));
        item.put("alert_id", new AttributeValue(alertid));
        item.put("information", new AttributeValue(information));
  

        return item;
    }
	
	private static ItemCollection<QueryOutcome> queryAlertHeader(AmazonDynamoDBClient dynamoDB, String tableName, String stopid) {
    	DynamoDB dynamoDB1 = new DynamoDB(dynamoDB);
 	   	Table table = dynamoDB1.getTable(tableName);
 	   	
 	   	HashMap<String, String> nameMap = new HashMap<String, String>();
 	   	nameMap.put("#nm", "stop_id"); 
        
 	   	HashMap<String, Object> valueMap = new HashMap<String, Object>();
 	   	valueMap.put(":yyyy", stopid);
        
   		QuerySpec spec = new QuerySpec()
   			.withKeyConditionExpression("#nm = :yyyy")
   			.withNameMap(nameMap)
   			.withValueMap(valueMap);
   	
   		ItemCollection<QueryOutcome> items = table.query(spec);
   		return items;
	}
	
	private static ItemCollection<QueryOutcome> queryAllAlert(AmazonDynamoDBClient dynamoDB, String tableName, String alertid) {
    	DynamoDB dynamoDB2 = new DynamoDB(dynamoDB);
 	   	Table table2 = dynamoDB2.getTable(tableName);
 	   	
 	   	HashMap<String, String> nameMap = new HashMap<String, String>();
 	   	nameMap.put("#nm", "alert_id"); 
        
 	   	HashMap<String, Object> valueMap = new HashMap<String, Object>();
 	   	valueMap.put(":yyyy", alertid);
        
   		QuerySpec spec = new QuerySpec()
   			.withKeyConditionExpression("#nm = :yyyy")
   			.withNameMap(nameMap)
   			.withValueMap(valueMap);
   	
   		ItemCollection<QueryOutcome> items = table2.query(spec);
   		return items;
	}
}

