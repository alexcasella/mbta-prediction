package edu.bu.mbta.predictionByRoute;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.model.AttributeAction;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.AttributeValueUpdate;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.DescribeTableRequest;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.PutItemRequest;
import com.amazonaws.services.dynamodbv2.model.PutItemResult;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.dynamodbv2.model.TableDescription;
import com.amazonaws.services.dynamodbv2.model.UpdateItemRequest;
import com.amazonaws.services.dynamodbv2.model.UpdateItemResult;
import com.amazonaws.services.dynamodbv2.util.Tables;

import edu.bu.mbta.api.PredictionsByRoute;
import edu.bu.mbta.entity.DirectionEntity;
import edu.bu.mbta.entity.PredictionsByRouteEntity;
import edu.bu.mbta.entity.StopEntity;
import edu.bu.mbta.entity.TripEntity;

public class GreenB {
	
	public static void GreenBPrediction(AmazonDynamoDBClient dynamoDB) throws Exception {
	    String tableName2 = "PredictionsByRoute_GreenB";

	    if (Tables.doesTableExist(dynamoDB, tableName2)) {
	    	System.out.println("Table " + tableName2 + " is already ACTIVE");
	    } else {
		    CreateTableRequest createTableRequest = new CreateTableRequest().withTableName(tableName2)
		        .withKeySchema(new KeySchemaElement().withAttributeName("stop_id").withKeyType(KeyType.HASH))
		        .withAttributeDefinitions(new AttributeDefinition().withAttributeName("stop_id").withAttributeType(ScalarAttributeType.S))
		        .withProvisionedThroughput(new ProvisionedThroughput().withReadCapacityUnits(1L).withWriteCapacityUnits(1L));
		        TableDescription createdTableDescription = dynamoDB.createTable(createTableRequest).getTableDescription();
		    System.out.println("Created Table: " + createdTableDescription);
		
		        // Wait for it to become active
		    System.out.println("Waiting for " + tableName2 + " to become ACTIVE...");
		    Tables.awaitTableToBecomeActive(dynamoDB, tableName2);
	    }
	        
	    DescribeTableRequest describeTableRequest2 = new DescribeTableRequest().withTableName(tableName2);
	    TableDescription tableDescription2 = dynamoDB.describeTable(describeTableRequest2).getTable();
	    System.out.println("Table Description: " + tableDescription2);
	
	    PredictionsByRouteEntity prediction = PredictionsByRoute.getPredictionByRoute("Green-B");
	    
	    ArrayList<DirectionEntity> direction = prediction.getDirection();
	    HashMap<String, TreeSet<String>> map = new HashMap<>();  
	    for(DirectionEntity dir : direction) {
	    	String direction_id = dir.getDirection_id();
	    	if(direction_id == null) continue;
	        ArrayList<TripEntity> trip = dir.getTrip();
	        for(TripEntity t : trip) {
	        	String trip_id = t.getTrip_id();
	        	if(trip_id == null) continue;
	        	ArrayList<StopEntity> stop = t.getStop();
	        	for(StopEntity st : stop) {
	        		String stop_id = st.getStop_id();
	        		if(stop_id == null || stop_id.equals("N/A")) continue;
	        		
	        		String pre_away = "";
	        		if(st.getPre_away() == null) {
	        			pre_away="N/A";
	        		} else {
	        			pre_away=st.getPre_away();
	        		}
	        		
	        		if(map.containsKey(stop_id)) {
	        			map.get(stop_id).add(pre_away);
	        		} else {
	        			TreeSet<String> value = new TreeSet<>(new Comparator<String>() {
	        	            public int compare(String s1, String s2) {
	    	                return Integer.compare(Integer.valueOf(s1), Integer.valueOf(s2));
	        	            }
	        			});
	        			value.add(pre_away);
	        			map.put(stop_id, value);
	        		}
	        		
	        	}
	        }
	    }
	    Set<String> set = map.keySet();
	    for(String id: set) {
	    	long yourmilliseconds = System.currentTimeMillis();
	    	SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy HH:mm:ss a");    
	    	Date resultdate = new Date(yourmilliseconds);
	    	
	        Map<String, AttributeValue> item = newItem(id, map.get(id).toString(), sdf.format(resultdate));
	        PutItemRequest putItemRequest = new PutItemRequest(tableName2, item);
	        PutItemResult putItemResult = dynamoDB.putItem(putItemRequest);
	        System.out.println("Result: " + putItemResult.toString());
	    }    

 
	}
	
    
	private static Map<String, AttributeValue> newItem(String stop_id, String pre_away, String create_time) {
        Map<String, AttributeValue> item = new HashMap<String, AttributeValue>();
        item.put("stop_id", new AttributeValue(stop_id));
        item.put("pre_away", new AttributeValue(pre_away));
        item.put("current_time", new AttributeValue(create_time));

        return item;
    }
	

    
    
}
