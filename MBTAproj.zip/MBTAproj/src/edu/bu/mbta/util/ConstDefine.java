package edu.bu.mbta.util;


public class ConstDefine {

	public static final String mbtaBaseURI = "http://realtime.mbta.com/developer/api/v2/";
	
	public static final String apiKey = "?api_key=TGmTHy9PgES2eVZlZ76Mjg&";
	
	public static final String format = "&format=json";
}
