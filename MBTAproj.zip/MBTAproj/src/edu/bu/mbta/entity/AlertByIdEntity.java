package edu.bu.mbta.entity;

public class AlertByIdEntity {

	private AlertEntity alert;

	public AlertEntity getAlert() {
		return alert;
	}

	public void setAlert(AlertEntity alert) {
		this.alert = alert;
	}

}
