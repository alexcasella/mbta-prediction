package edu.bu.mbta.entity;

public class EffectPeriodEntity {
	
	private String effect_start;
	
	private String effect_end;

	public String getEffect_start() {
		return effect_start;
	}

	public void setEffect_start(String effect_start) {
		this.effect_start = effect_start;
	}

	public String getEffect_end() {
		return effect_end;
	}

	public void setEffect_end(String effect_end) {
		this.effect_end = effect_end;
	}
	
	
}
