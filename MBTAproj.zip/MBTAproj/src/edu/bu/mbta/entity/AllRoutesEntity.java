package edu.bu.mbta.entity;
import java.util.ArrayList;

public class AllRoutesEntity {
	private ArrayList<ModeEntity> mode;

    public ArrayList<ModeEntity> getMode() {
        return mode;
    }

    public void setMode(ArrayList<ModeEntity> mode) {
        this.mode = mode;
    }

}
