package org.pranay.mbta.messenger.resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.pranay.mbta.messenger.db.predictionByRoute;

@Path("/prediction")
public class predictionResource {


	@GET
	@Path("/{Line}/{Start}")
	@Produces(MediaType.APPLICATION_JSON)
	
	public String Green(@PathParam("Line") String line, 
			            @PathParam("Start") String start){

			predictionByRoute db = new predictionByRoute();
			String time = db.query(line, start);
			return time;
		}
}
