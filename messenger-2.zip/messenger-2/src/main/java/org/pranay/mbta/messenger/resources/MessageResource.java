package org.pranay.mbta.messenger.resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.simple.JSONObject;

import com.pranay.mbta.messenger.db.alertByStop;


@Path("/alertHeader")
public class MessageResource {


	@GET
	@Path("/{Line}/{Start}")
	@Produces(MediaType.APPLICATION_JSON)
	
	public String Green(@PathParam("Line") String line, 
			            @PathParam("Start") String start){

			alertByStop db = new alertByStop();
			String alert = db.query(line, start);
			return alert;
		}

	}
	
